//var Ownable = artifacts.require("ownership/Ownable.sol");

module.exports = function(deployer) {
  //deployer.deploy(Ownable);
};
